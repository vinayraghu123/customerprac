package com.infosys.customerdetails.response;

public class CustLoginDetailsResponse {
	
	private long loginId;
	private String username;



	public long getLoginId() {
		return loginId;
	}
	public void setLoginId(long loginId) {
		this.loginId = loginId;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}


}
